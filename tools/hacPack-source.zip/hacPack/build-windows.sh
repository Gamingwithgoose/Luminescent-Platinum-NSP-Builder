set -eu
make clean_full
make -j4 CC=x86_64-w64-mingw32ucrt-gcc AR=x86_64-w64-mingw32ucrt-ar WINDOWS=1 LDFLAGS="-static -lmbedtls -lmbedx509 -lmbedcrypto -lws2_32"
